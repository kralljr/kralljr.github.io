cleaneddata <- matrix(sample(seq(1, 100), 20), nrow = 4)
