# Day 2 (V2) solutions to exercises
# January 2016


########
########
# Module 1-4
########
########

# For Exercises in module 4, be sure your working directory 
# is set to where all the data files are


########
# Exercise 4a
vlbw <- read.csv("vlbw.csv", stringsAsFactors = F)












########
# Exercise 4b
flu <- read.csv("googleflu.csv", stringsAsFactors = F)
flu$Date <- as.Date(flu$Date, format = "%Y-%m-%d")
flu$Date <- format(flu$Date, format = "%d%b%y")








########
# Exercise 4c
vec1 <- rnorm(10)
which(vec1 > 0)
vec1[vec1 > 0]











########
# Exercise 4d
x <- rnorm(20)
mat1 <- matrix(x, nrow = 4, ncol = 5)
mat1
mat1[3, ]
mat1[4, 2]










########
# Exercise 4e
flumiss <- read.table("googleflumissing.txt", header = T)
table(complete.cases(flumiss))
flucomplete <- flumiss[complete.cases(flumiss), ]
write.table(flucomplete, "googleflucomplete.txt", row.names = F)













########
########
# Module 1-5
########
########


# For exercises in module 1-5, make sure working directory is set to where "vlbw.csv" is located
library(dplyr)
library(epitools)
library(contrast)
vlbw <- read.csv("vlbw.csv", stringsAsFactors = F)
vlbw <- select(vlbw, ivh, bwt, gest, pneumo, delivery, twn)
vlbw <- vlbw[complete.cases(vlbw), ]
vlbw <- mutate(vlbw, outcome = 1 * ((ivh %in% c("definite", "possible"))))

vlbw$ivh <- factor(vlbw$ivh)
lm1 <- lm(gest ~ ivh + bwt, data = vlbw)





########
# Exercise 5a
gest_ivh <- filter(vlbw, outcome == 1) %>% select(., gest)
gest_no <- filter(vlbw, outcome == 0) %>% select(., gest)
t.test(gest_ivh, gest_no, var.equal = T, alternative = "less" )









########
# Exercise 5b
chi2 <- chisq.test(vlbw$outcome, vlbw$pneumo)
chi2$statistic










########
# Exercise 5c
power.t.test(n = 10, delta = 2, sd = 2, sig.level = 0.1, 
    type = "two.sample", alternative = "two.sided")








########
# Exercise 5d
head(lm1$resid)
hist(lm1$resid)











########
# Exercise 5e
newdat1 <- data_frame("definite", 1300)
colnames(newdat1) <- c("ivh", "bwt")
predict(lm1, newdata = newdat1)










########
# Exercise 5f
lm1 <- lm(gest ~ ivh, data = vlbw)
lev1 <- levels(vlbw$ivh)
contrast(lm1, a = list(ivh = lev1), b = list(ivh = "definite"))










########
# Exercise 5g
glm1 <- glm(outcome ~ delivery, data = vlbw, family = "binomial")
















########
# Exercise 5h
diab <- read.csv("diabetes.csv")
diab <- select(diab, diab1, chol, hdl, age:weight, waist: hip)
lm1 <- glm(diab1 ~., data = diab, family = "binomial")
ci1 <- exp(confint(lm1)[-1, ])
or <- exp(lm1$coef[-1])










########
########
# Module 2-1
########
########

# For exercises in module 2-1, make sure working directory is set to where "vlbw.csv" is located
library(contrast)
library(dplyr)
library(tidyr)
vlbw <- read.csv("vlbw.csv", stringsAsFactors = F)
vlbw <- select(vlbw, bwt, gest, ivh, delivery, twn, pneumo)
vlbw <- vlbw[complete.cases(vlbw), ]
vlbw <- mutate(vlbw,  id = 1 : nrow(vlbw))
set.seed(1807)
n <- nrow(vlbw)
weight1 <- vlbw$bwt + 150 + rnorm(n, sd = 10) 
weight2 <- weight1 + rnorm(n, sd = 10)
weights <- data.frame(seq(1, nrow(vlbw)), weight1, weight2)
colnames(weights) <- c("id", "weight_1", "weight_2")
weights <- tbl_df(weights)
vlbw_2 <- filter(vlbw, id < 35)






########
# Exercise 1a

# IDs in weights dataset
m_vlbw <- left_join(vlbw_2, weights)
n_distinct(m_vlbw$id)
m_vlbw <- left_join(weights, vlbw_2)
n_distinct(m_vlbw$id)













########
########
# Module 2-2
########
########


# Necessary for exercises in module 2-2
iris <- mutate(iris, petlencut = cut(Petal.Length, breaks = 4))
aq1 <- mutate(airquality, Month = factor(Month))

iris_sum <- group_by(iris, Species) %>% 
    summarise_each(., funs(mean), Sepal.Length : Petal.Width)
means <- gather(iris_sum, "Variable", "Mean", 2 : 5)
sds <- group_by(iris, Species) %>% 
    summarise_each(., funs(sd), Sepal.Length : Petal.Width) %>%
    gather(., "Variable", "SD", 2 : 5)

g1 <- ggplot(iris, aes(x = Sepal.Width, y = Sepal.Length, 
                       color = Species)) + geom_point()





########
# Exercise 2a
ggplot(iris, aes(x = Sepal.Width, y = Sepal.Length, 
    color = petlencut)) + geom_point()








########
# Exercise 2b
ggplot(aq1, aes(x = Day, y = Ozone, color = Month)) + 
    geom_line(aes(linetype = Month))









########
# Exercise 2c
CIdat <- full_join(means, sds)
CIdat <- mutate(CIdat, LB = Mean - SD, UB = Mean + SD)
 








########
# Exercise 2d
ggplot(CIdat, aes(y = Mean, x = Species, color = Species)) +
    geom_errorbar(aes(ymin = LB, ymax = UB), width = 0) + geom_point() +
    facet_wrap(~ Variable, scales = "free_y")










########
########
# Module 2-3
########
########

# For exercises in module 2-3
library(dplyr)
vlbw <- read.csv("vlbw.csv", stringsAsFactors = F)
vlbw <- select(vlbw, bwt, gest, ivh, delivery, twn, pneumo) 
vlbw <- vlbw[complete.cases(vlbw), ]
vlbw <- mutate(vlbw, outcome = 1 * ((ivh %in% c("definite", "possible"))))










########
# Exercise 3a
vlbw2 <- read.csv("vlbw.csv", stringsAsFactors = F)
vlbw2 <- mutate(vlbw2, outcome = ifelse(ivh %in% c("definite", "possible"), 
      1, ifelse(ivh == "absent", 0, NA)))
table(vlbw2$outcome, vlbw2$ivh, exclude = NULL)












########
# Exercise 3b
vars <- colnames(iris)[2 : 4]
par(mfrow = c(1, 3))
for(i in 2 : 4) {
    plot(iris[, i], iris[, "Sepal.Length"], xlab = vars[i],
         ylab = "Sepal.Length")
}







########
# Exercise 3c
lev1 <- levels(iris$Species)
m_seplen <- vector()
for(i in 1 : length(lev1)) {
    m_seplen[i] <- mean(iris$Sepal.Length[iris$Species == lev1[i]])
}
tapply(iris$Sepal.Length, iris$Species, mean)
group_by(iris, Species) %>% summarise(., mean(Sepal.Length))












########
# Exercise 3d
nicescatter <- function(data = iris, xvar = "Sepal.Length", 
                        yvar = "Sepal.Width", colorvar = "Species", 
                        cols1 = c(1, 2, 3)) {
    
    cols <- cols1[data[, colorvar]]
    plot(data[, xvar], data[, yvar], col = cols, pch = 16,
         xlab = xvar, ylab = yvar)
    legend("topright", legend = levels(data[, colorvar]), 
           col = cols1, pch = 16)
}
nicescatter()




########
########
# Overall exercise 2
########
########
# Load data
data(airquality)
# Create Date variable
airquality <- mutate(airquality, Month = paste0("0", Month), 
                     Day = ifelse(Day < 10, paste0("0", Day), Day))
airquality <- unite_(airquality, "Date", c("Month", "Day"), sep = "-", remove = F)
airquality <- mutate(airquality, Date = as.Date(paste0("1973-", Date)))

# Transform data
airquality <- gather(airquality, "Variable", "Value", Ozone : Temp)

# Plot time series
ggplot(airquality, aes(x = Date, y = Value)) + geom_line() + 
    facet_wrap(~ Variable, scales = "free_y")

# Compute mean, min, max
airquality <- mutate(airquality, Day = as.numeric(Day))
gaq <- group_by(airquality, Day, Variable)
gaq <- summarise(gaq, mn1 = mean(Value, na.rm = T), 
                 min1 = min(Value, na.rm = T), 
                 max1 = max(Value, na.rm = T))

# Plot time series
ggplot(gaq, aes(x = Day, y = mn1)) + 
    geom_line() + ylab("Mean (minimum, maximum)") +
    geom_ribbon(aes(ymin = min1, ymax = max1), alpha = 0.2) +
    facet_wrap(~ Variable, scales = "free_y")



