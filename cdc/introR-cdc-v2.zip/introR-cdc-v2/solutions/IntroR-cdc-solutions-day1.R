# Day 1 solutions to exercises
# January 2016


########
########
# Module 1-1
########
########

# items needed for module 1-1
vectorstring <- c("R", "is", "useful", "for", "data", "analysis")



########
# Exercise 1a
vectorstring[seq(1, length(vectorstring), by = 2)]















########
# Exercise 1b
vec1 <- rnorm(20)
vec2 <- rnorm(20)
meanvec <- c(mean(vec1), mean(vec2))
meanvec












########
# Exercise 1c
vec <- rnorm(100)
sumvec <- summary(vec)
sumvec
sumvec[c(2, 3, 5)]












########
# Exercise 1d
set.seed(10)
n <- 20
heights <- rnorm(n, mean = 70, sd = 4)
zstat <- (mean(heights) - 68) / (4 / sqrt(n))
pnorm(zstat, lower.tail = F) * 2










########
########
# Module 1-2
########
########


# For exercises in module 1-2
library(dplyr)
data(iris)

########
# Exercise 2a
newiris <- filter(iris, Petal.Width > 1.5 & 
    ((Species == "virginica") | (Species == "versicolor")))
newiris <- select(newiris, Sepal.Length, Sepal.Width, Petal.Length)
head(newiris)

# Alternative approach
newiris2 <- filter(iris, Petal.Width > 1.5 & 
    (Species %in% c("virginica", "versicolor")))
newiris2 <- select(newiris2, Sepal.Length : Petal.Length)
all.equal(newiris, newiris2)









########
# Exercise 2b
iris2 <- select(iris, Sepal.Length, Species)
iris2 <- mutate(iris2, 
    stdseplen = (Sepal.Length - mean(Sepal.Length)) / sd(Sepal.Length))
head(iris2)


# Alternative approach
iris2 <- mutate(iris2, mn = mean(Sepal.Length), 
    sd = sd(Sepal.Length), stdseplen = (Sepal.Length - mn) / sd)
head(iris2)


mean(iris2$stdseplen)
sd(iris2$stdseplen)





########
# Exercise 2c
s1 <- group_by(iris, Species) %>%
    summarise_each(., funs(mean, sd))
data.frame(s1)










########
# Exercise 2d
s1 <- mutate(iris, medpetlen = Petal.Length < median(Petal.Length), 
    medpetwid = Petal.Width < median(Petal.Width)) %>%
    group_by(., medpetlen, medpetwid) %>% 
    summarise_each(., funs(mean), Sepal.Length, Sepal.Width)
data.frame(s1)









########
########
# Module 1-3
########
########



# For exercises in module 1-3
library(dplyr)
data(iris)

########
# Exercise 3a
pch1 <- c(1, 2, 3)
pch1 <- pch1[iris$Species]
plot(x = iris$Sepal.Length, y = iris$Sepal.Width, 
     xlab = "Sepal length",
     ylab = "Sepal width", pch = pch1,
     main = "Scatterplot of Iris data")










########
# Exercise 3b
plot(x = iris$Sepal.Length, y = iris$Sepal.Width, 
    col = iris$Species)
mn1 <- group_by(iris, Species) %>% 
    summarise(., mean1 = mean(Sepal.Width))
abline(h = mn1$mean1, col = 1 : 3)










########
# Exercise 3c
pch0 <- c(1, 2, 3)
pch1 <- pch0[iris$Species]
mn1 <- group_by(iris, Species) %>% 
    summarise(., mean1 = mean(Sepal.Width))

plot(x = iris$Sepal.Length, y = iris$Sepal.Width, 
     col = iris$Species, pch = pch1)
abline(h = mn1$mean1, col = 1 : 3)
legend("topright", legend = levels(iris$Species), 
     col = 1 : 3, pch = pch0, lty = 1)











########
# Exercise 3d
hist(iris$Sepal.Length, probability = T, breaks = 20)









########
########
# Overall exercise 1
########
########
head(airquality)
airquality <- mutate(airquality, monthname = factor(Month, levels = 5 : 9, 
    labels = c("May", "June", "July", "August", "September")))
gaq <- group_by(airquality, Month)
summarise_each(gaq, funs(mean(., na.rm = T)), Ozone : Temp)

lms <- lm(Ozone ~ Solar.R, data = airquality)$coef
lmw <- lm(Ozone ~ Wind, data = airquality)$coef
lmt <- lm(Ozone ~ Temp, data = airquality)$coef


#png("overallex1.png", height = 300, width = 1000)
par(mfrow = c(1, 4), ps = 18)
cols <- c(1 : 5)[airquality$monthname]
plot(Ozone ~ Solar.R, data = airquality, col = cols)
abline(a = lms[1], b = lms[2])

plot(Ozone ~ Wind, data = airquality, col = cols)
abline(a = lmw[1], b = lmw[2])

plot(Ozone ~ Temp, data = airquality, col = cols)
abline(a = lmt[1], b = lmt[2])

plot(1, 1, type = "n", axes = F, xlab = "", ylab = "")
legend("topleft", legend = levels(airquality$monthname), 
       col = 1 : 5, pch = 1)
#dev.off()







########
########
# Module 1-4
########
########

# For exercises, be sure working directory is set to where "googleflu.csv" and "googleflumissing.txt" are located

########
# Exercise 4a
# Old way
flu <- read.csv("googleflu.csv", stringsAsFactors = FALSE)
# Other way
flu2 <- read.table("googleflu.csv", sep = ",", header = T, 
    stringsAsFactors = F)
all.equal(flu, flu2)











########
# Exercise 4b
flu <- read.csv("googleflu.csv", stringsAsFactors = F)
flu$Date <- as.Date(flu$Date, format = "%Y-%m-%d")
flu$Date <- format(flu$Date, format = "%d%b%y")
















########
# Exercise 4c
flumiss <- read.table("googleflumissing.txt", header = T)
table(complete.cases(flumiss))
flucomplete <- flumiss[complete.cases(flumiss), ]
write.table(flucomplete, "googleflucomplete.txt", row.names = F)















########
# Exercise 4d
set.seed(535895)
mat2 <- matrix(rnorm(20), nrow = 4)
class(mat2[, 1])
dim(mat2[, 1])
mat2[, 1, drop = F]












########
########
# Module 1-5
########
########


# For exercises in module 1-5, make sure working directory is set to where "vlbw.csv" is located
library(dplyr)
library(epitools)
vlbw <- read.csv("vlbw.csv", stringsAsFactors = F)
vlbw <- select(vlbw, ivh, bwt, gest, pneumo, delivery, twn)
vlbw <- vlbw[complete.cases(vlbw), ]
vlbw <- mutate(vlbw, outcome = 1 * ((ivh %in% c("definite", "possible"))))







########
# Exercise 5a
head(vlbw$outcome == 1)
gest_ivh <- vlbw$gest[vlbw$outcome == 1]
head(gest_ivh)
gest_no <- vlbw$gest[vlbw$outcome == 0]
head(gest_no)
var.test(gest_ivh, gest_no)
t.test(gest_ivh, gest_no, var.equal = T, alternative = "less" )







########
# Exercise 5b
chsq <- chisq.test(vlbw$outcome, vlbw$delivery, correct = F)
pval1 <- chsq$p.value
ts <- sum((chsq$observed - chsq$expected)^2 / chsq$expected)
pval2 <- pchisq(ts, 1, lower.tail = F)
all.equal(pval1, pval2)








########
# Exercise 5c
table_del <- table(vlbw$delivery, vlbw$pneumo)
epi_del <- epitab(table_del, method = "oddsratio", rev = "both") 
epi_del$tab[2, c("lower", "upper")]












########
# Exercise 5d
power.t.test(n = 10, delta = 2, sd = 2, sig.level = 0.1, 
    type = "two.sample", alternative = "two.sided")












########
########
# Module 1-6
########
########



# For exercises in module 1-6, make sure working directory is set to where "vlbw.csv" is located
library(contrast)
library(dplyr)
vlbw <- read.csv("vlbw.csv", stringsAsFactors = F)
vlbw <- select(vlbw, ivh, bwt, gest, pneumo, delivery, twn)
vlbw <- vlbw[complete.cases(vlbw), ]
vlbw <- mutate(vlbw, outcome = 1 * ((ivh %in% c("definite", "possible"))))
vlbw$ivh <- factor(vlbw$ivh)
lm1 <- lm(gest ~ ivh + bwt, data = vlbw)
lm2 <- lm(gest ~ ivh + bwt + delivery + pneumo + twn, data = vlbw)
slm2 <- summary(lm2)$coef[-1, ]
slm2



########
# Exercise 6a

head(lm1$resid)
hist(lm1$resid)
all.equal(lm1$resid, vlbw$gest - lm1$fitted)










########
# Exercise 6b
lm1 <- lm(gest ~ ivh + bwt, data = vlbw)$coef[c(1, 4)]
lmy <- lm(gest ~ ivh, data = vlbw)$resid
lmx <- lm(bwt ~ ivh, data = vlbw)$resid

plot(lmy ~ lmx, xlab = "BWT | IVH", ylab = "GEST | IVH",
     main = "Added variable plot")
abline(a = 0, b = lm1[2], col = "red")











########
# Exercise 6c
lm1 <- lm(gest ~ ivh, data = vlbw)
lev1 <- levels(vlbw$ivh)
contrast(lm1, a = list(ivh = lev1), b = list(ivh = "possible"))











########
# Exercise 6d
glm(outcome ~ delivery, data = vlbw, family = binomial(link = "log"))



















########
########
# Overall exercise 2
########
########
diab <- read.csv("diabetes.csv")
diab <- select(diab, diab1, chol, hdl, age:weight, waist: hip)
lm1 <- glm(diab1 ~., data = diab, family = "binomial")
lm1 <- summary(lm1)$coef[-1, ]
lm1 <- data.frame(rownames(lm1), lm1)
lm1 <- rename(lm1, Variable = rownames.lm1., SE = Std..Error)
lm1 <- mutate(lm1, ME = 1.96 * SE, LB = Estimate - ME, UB = Estimate + ME,
    OR = exp(Estimate), orUB = exp(UB), orLB = exp(LB))
head(lm1)

#png("overallex2.png")
par(mar = c(7, 4, 4, 2))
xval <- 1 : nrow(lm1)
plot(xval, lm1$OR, las = 2, pch = 16, 
     ylim = c(min(lm1$orLB), max(lm1$orUB)),
     ylab = "Odds ratio", xlab = "", axes = F)
box()
axis(2)
axis(1, at = xval, labels = lm1$Variable, las = 2)
segments(x0 = xval, y0 = lm1$orLB, y1 = lm1$orUB)
abline(h = 1, lty = 2, col = "grey")
#dev.off()




