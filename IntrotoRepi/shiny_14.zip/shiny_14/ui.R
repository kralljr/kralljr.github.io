# load library
library(shiny)

# Define how application looks
shinyUI(fluidPage(
  # Add title
  titlePanel("Histogram of variables in airquality dataset"),
  # Define sidebar
  sidebarLayout(
      
    # Add inputs in dropdown menu (select)
    sidebarPanel(
      selectInput("variable", label = "Variable:", choices = list("Ozone" = "Ozone", 
          "Solar" = "Solar.R", "Wind" = "Wind", "Temp" = "Temp"), 
          selected = "Ozone"),
      checkboxInput("may", "May", value = T),
      checkboxInput("june", "June", value = T),
      checkboxInput("july", "July", value = T),
      checkboxInput("august", "August", value = T),
      checkboxInput("september", "September", value = T)),
      

    
    
    # Add outputs in main panel
    mainPanel(
      textOutput("text1"),
      plotOutput("plot"))
  
  )
))



