# File to define input and output
library(dplyr)
shinyServer(function(input, output) {
	
  # Reactive variables change with input (checkboxes etc.)
  variable <- reactive({input$variable})
  month <- reactive({input$month})
  may <- reactive({input$may})
  june <- reactive({input$june})
  july <- reactive({input$july})
  august <- reactive({input$august})
  sep <- reactive({input$september})

  # number of months
  monthsN <- reactive({which(c(may(), june(), july(), august(), sep()))})
  # months label
  monthsL <- reactive({paste0(c("May", "June", "July", "August", "September")[monthsN()], 
    collapse = ", ")})
  
  
  
  # Define output based on variables (need () to make reactive)
  output$text1 <- renderText({paste0("Variable: ", variable(), ", Months: ", 
    monthsL())})

  #dat1 <- airquality[airquality$Month %in% months, variable()]
  # Define output plot
  dat1 <- reactive({airquality[airquality$Month %in% (monthsN() + 4), variable()]})
  output$plot <- renderPlot({
    hist(dat1(), main = "", xlab = "")})
  


})
